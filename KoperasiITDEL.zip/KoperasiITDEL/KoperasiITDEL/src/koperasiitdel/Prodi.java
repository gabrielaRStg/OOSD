/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
public enum Prodi {

    D4TRPL,D3TI, D3TK, S1IF, S1SI, S1MR, S1TB;

    private String lable;

    Prodi() {
    }

    public static String getVal(Prodi lable) {
        if(Prodi.D4TRPL.equals(lable)) {
            return "D4 Teknologi Rekayasa Perangkat Lunak";
        } else if(Prodi.D3TI.equals(lable)) {
            return "D3 Teknologi Informasi";
        } else if(Prodi.D3TK.equals(lable)) {
            return "D3 Teknologi Komputer";
        } else if(Prodi.S1IF.equals(lable)) {
            return "S1 Informatika";
        } else if(Prodi.S1SI.equals(lable)) {
            return "S1 Sistem Informasi";
        } else if(Prodi.S1MR.equals(lable)) {
            return "S1 Manajemen Rekayasa";
        } else if(Prodi.S1TB.equals(lable)) {
            return "S1 Teknik Bioproses";
        }else {
            return "_";
        }
    }

}
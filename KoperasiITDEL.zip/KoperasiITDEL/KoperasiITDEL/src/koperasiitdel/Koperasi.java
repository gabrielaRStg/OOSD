/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
import java.util.Scanner;

public class Koperasi implements Display{
    String namaKoperasi,lokasi, ketua,wakil,sekre,benda;

    public Koperasi() {
    }
    
    public Koperasi(String namaDesa,String lokasi, String ketua, String wakil, String sekre, String benda) {
        this.namaKoperasi = namaKoperasi;
        this.lokasi = lokasi;
        this.ketua = ketua;
        this.wakil = wakil;
        this.sekre = sekre;
        this.benda = benda;
        
    }
    public void setKoperasi(String namaKoperasi,String lokasi, String ketua, String wakil, String sekre, String benda) {
        this.namaKoperasi = namaKoperasi;
        this.lokasi = lokasi;
        this.ketua = ketua;
        this.wakil = wakil;
        this.sekre = sekre;
        this.benda = benda;
        
    }
    //Profil Koperasi
    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getKetua() {
        return ketua;
    }

    public void setKetua(String ketua) {
        this.ketua = ketua;
    }

    public String getWakil() {
        return wakil;
    }

    public void setWakil(String wakil) {
        this.wakil = wakil;
    }

    public String getSekre() {
        return sekre;
    }

    public void setSekre(String sekre) {
        this.sekre = sekre;
    }

    public String getBenda() {
        return benda;
    }

    public void setBenda(String benda) {
        this.benda = benda;
    }

    public String getNamaKoperasi() {
        return namaKoperasi;
    }

    public void setNamaKoperasi(String namaKoperasi) {
        this.namaKoperasi = namaKoperasi;
    }

    @Override
    public void display() {
        System.out.println("Nama Koperasi : "+getNamaKoperasi()+"\nLokasi : "+getLokasi()+"\nKetua : "+getKetua()+"\nWakil Ketua : "+getWakil()+"\nSekertaris : "+getSekre()+"\nBendara : "+getBenda());
    }
    
    public void editProfil(){
        System.out.println("\t========Edit Profil Koperasi=======");
        Scanner scan =  new Scanner(System.in);
        System.out.print("Nama Koperasi : ");
        namaKoperasi = scan.next();
        System.out.print("Lokasi : ");
        lokasi = scan.next();
        System.out.print("Ketua : ");
        ketua = scan.next();
        System.out.print("Wakil Ketua : ");
        wakil = scan.next();
        System.out.print("Sekertaris : ");
        sekre = scan.next();
        System.out.print("Bendahara : ");
        benda = scan.next();
    }
}
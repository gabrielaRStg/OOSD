/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
import java.util.Scanner;

public class MainKoperasi {

    /**
     * @param args the command line arguments
     */
    static String namaKoper, lokasi, ketua, wakil, sekre, benda, isi, biaya;
    static String Isi, judul, hukuman;

    public static void main(String[] args) {

        MainKoperasi koperasi = new MainKoperasi();
        Autentikasi auten = new Autentikasi();
        Barang barang = new Barang();
        Penjualan penjualan = new Penjualan();
        Pemesanan pesan = new Pemesanan();
        Komentar komen = new Komentar();
        Scanner scan = new Scanner(System.in);
        Komentar.shows show= komen.new shows();

        //Profil Koperasi
        Koperasi profil = new Koperasi();
        Koperasi Koperasi[] = new Koperasi[100];
        for (int i = 0; i < Koperasi.length; i++) {
            Koperasi[i] = new Koperasi(namaKoper, lokasi, ketua, wakil, sekre, benda);
        }
        Koperasi[0].setKoperasi("Koperasi IT DEL", "Sitoluama", "Gabriela", "Jensri", "Tesyalonica", "Rusdeni");

        //Peraturan Koperasi
        PeraturanKoperasi peraturan = new PeraturanKoperasi();
        PeraturanKoperasi PeraturanKoperasi[] = new PeraturanKoperasi[100];
        for (int i = 0; i < PeraturanKoperasi.length; i++) {
            PeraturanKoperasi[i] = new PeraturanKoperasi(judul, Isi, hukuman);
        }

        PeraturanKoperasi[0].setPeraturanKoperasi("Mencuri", "Berat", "Lapor Kemahasiswaan");
        PeraturanKoperasi[1].setPeraturanKoperasi("Membuang sampah sembarang", "Ringan", "Sanksi Sosial");
        PeraturanKoperasi[2].setPeraturanKoperasi("Mengambil Barang tanpa permisi", "Sedang", "Sanksi Sosial");

        //Event
        Event event = new Event();
        event.addEvent("Diskon 10%", "10/12/2023", "Koperasi");
        event.addEvent("Diskon 5%", "05/10/2023", "Koperasi");

        //Barang
        barang.addBarang("Bengbeng", 5, 20000, TipeBarang.Makanan, "Laguboti");

        //Komentar
        Komentar komentar = new Komentar();
        int awal, utama, sub;
        do {
            koperasi.menuLogin();
            System.out.print("Login sebagai : ");
            awal = scan.nextInt();
            if (awal == 1) {

                auten.loginPetugas();
                do {
                    koperasi.menuUtamaPetugas();
                    System.out.print("Pilih : ");
                    utama = scan.nextInt();   
                    if (utama == 1) {
                        do {
                            for (int i = 0; i < Koperasi.length; i++) {
                                if (Koperasi[i].getNamaKoperasi() != null) {
                                    System.out.println("\n\t =======Profil Koperasi========");
                                    Koperasi[i].display();
                                }
                            }
                            System.out.println("1. Edit ");
                            System.out.println("0. Back");
                            System.out.print("Pilih : ");
                            sub = scan.nextInt();
                            if (sub == 1) {
                                koperasi.editProfil();
                                Koperasi[0].setKoperasi(namaKoper, lokasi, ketua, wakil, sekre, benda);
                            }

                        } while (sub != 0);
                    }
                    if (utama == 2) {
                        do {
                            System.out.println("\n\t =======Peraturan Koperasi========");
                            for (int i = 0; i < PeraturanKoperasi.length; i++) {
                                if (PeraturanKoperasi[i].getJudul() != null) {
                                    System.out.println(i + 1 + ".");
                                    PeraturanKoperasi[i].display();
                                }
                            }
                            System.out.println("1. Tambah Peraturan");
                            System.out.println("2. Edit Peraturan");
                            System.out.println("3. Hapus Peraturan");
                            System.out.println("0. Keluar");
                            System.out.print("Pilih : ");
                            sub = scan.nextInt();
                            if (sub == 1) {
                                int x = 0;
                                int t = 0;
                                for (int i = 0; i < PeraturanKoperasi.length; i++) {
                                    if (PeraturanKoperasi[i].getJudul() == null) {
                                        t = i;
                                        x = 1;
                                        break;
                                    } else {

                                    }
                                }
                                if (x == 1) {
                                    System.out.println("==================================");
                                    System.out.printf("Judul : ");
                                    judul = scan.next();
                                    PeraturanKoperasi[t].setJudul(judul);
                                    System.out.printf("Tingkat Pelanggaran : ");
                                    Isi = scan.next();
                                    PeraturanKoperasi[t].setIsi(Isi);
                                    System.out.printf("Hukuman : ");
                                    hukuman = scan.next();
                                    PeraturanKoperasi[t].setHukuman(hukuman);
                                    System.out.println("==================================");
                                    System.out.println(" Data Sukses Ditambahkan ");
                                } else {
                                    System.out.println("Data gagal di tambahkan");
                                }
                            }

                            if (sub == 2) {
                                System.out.println("=====Edit Peraturan=====");
                                for (int i = 0; i < PeraturanKoperasi.length; i++) {
                                    if (PeraturanKoperasi[i].getJudul() != null) {
                                        System.out.println(i + 1 + ".");
                                        PeraturanKoperasi[i].display();
                                    }
                                }
                                System.out.println("Pilih aturan ke : ");
                                int in = scan.nextInt();
                                int ac = in - 1;
                                System.out.printf("Judul  : ");
                                judul = scan.next();
                                System.out.print("Tingkat : ");
                                Isi = scan.next();
                                System.out.printf("Hukuman : ");
                                hukuman = scan.next();
                                PeraturanKoperasi[ac].setPeraturanKoperasi(judul, Isi, hukuman);
                            }

                            if (sub == 3) {
                                System.out.printf("Masukkan Peraturan ke : ");
                                int in = scan.nextInt();
                                int ac = in - 1;
                                PeraturanKoperasi[ac].setPeraturanKoperasi(null, null, null);
                                System.out.println("-----Data Sukses di Hapus-----");
                                for (int i = ac + 1; i < PeraturanKoperasi.length; i++) {
                                    PeraturanKoperasi[i - 1] = PeraturanKoperasi[i];
                                }
                                PeraturanKoperasi[PeraturanKoperasi.length - 1].setPeraturanKoperasi(null, null, null);
                            }
                        } while (sub != 0);
                    }
                    if (utama == 3) {
                        int dl;
                        do {
                            System.out.println("======= Barang =======");
                            barang.tampilkanBarang();
                            System.out.println("\n");

                            System.out.println("1. Tambah Barang");
                            System.out.println("2. Edit Barang");
                            System.out.println("3. Hapus Barang");
                            System.out.println("4. Daftar Pemesanan");
                            System.out.println("0. Keluar");
                            System.out.println("Pilih : ");
                            sub = scan.nextInt();
                            if (sub == 1) {
                                try {
                                String nama, tipe, alamat;
                                int jumlah_barang, harga;
                                System.out.printf("Nama : ");
                                nama = scan.next();
                                System.out.printf("Jumlah Barang : ");
                                jumlah_barang = scan.nextInt();
                                System.out.printf("Harga : ");
                                harga = scan.nextInt();
                                System.out.println("Pilihan : Makanan, Minuman, Jajan");
                                System.out.printf("Tipe : ");
                                tipe = scan.next();
                                System.out.printf("Alamat : ");
                                alamat = scan.next();
                                barang.addBarang(nama, jumlah_barang, harga, TipeBarang.valueOf(tipe), alamat);
                                 }catch (Exception e){
                                     System.err.println("Barang Gagal Ditambahkan."); //Tulisan Berwarna Merah
                                 }

                            }
                            if (sub == 2) {
                                String nama, tipe, alamat;
                                int jumlah_barang, harga;
                                System.out.println("Pilih Barang : ");
                                dl = scan.nextInt();

                                if (dl > 0) {
                                    System.out.printf("Nama : ");
                                    nama = scan.next();
                                    System.out.printf("Jumlah Barang : ");
                                    jumlah_barang = scan.nextInt();
                                    System.out.printf("Harga : ");
                                    harga = scan.nextInt();
                                    System.out.println("Pilihan : Makanan, Minuman, Jajan");
                                    System.out.printf("Tipe : ");
                                    tipe = scan.next();
                                    System.out.printf("Alamat : ");
                                    alamat = scan.next();
                                    barang.updateBarang(nama, jumlah_barang, harga, TipeBarang.valueOf(tipe), alamat, dl - 1);
                                } else {
                                    break;
                                }

                            }
                            if (sub == 3) {
                                System.out.println("Pilih Barang : ");
                                dl = scan.nextInt();
                                if (dl > 0) {
                                    barang.deleteBarang(dl - 1);
                                } else {
                                    break;
                                }
                            }

                            if (sub == 4) {
                                int ops;
                                int jumlah_barang;
                                String nama, status, lokasi;
                                long nim;
                                Prodi prodi;
                                pesan.show();
                                String satu = "Tolak";
                                String dua = "Terima";
                                //                            pesan.
                                System.out.println("Pilih pesanan : ");
                                ops = scan.nextInt();
                                System.out.println("Action :");
                                System.out.println("1. Terima");
                                System.out.println("2. Tolak");
                                System.out.println("Pilih");
                                //                           
                                dl = scan.nextInt();
                                if (dl == 1) {
                                    pesan.updatePesanan(ops - 1, jumlah_barang = pesan.pemesanan.get(ops - 1).jumlah_barang, nama = pesan.pemesanan.get(ops - 1).nama, nim = pesan.pemesanan.get(ops - 1).nim, prodi = pesan.pemesanan.get(ops - 1).prodi, lokasi = pesan.pemesanan.get(ops - 1).lokasi, status = dua);
                                }
                                if (dl == 2) {
                                    pesan.updatePesanan(ops - 1, jumlah_barang = pesan.pemesanan.get(ops - 1).jumlah_barang, nama = pesan.pemesanan.get(ops - 1).nama, nim = pesan.pemesanan.get(ops - 1).nim, prodi = pesan.pemesanan.get(ops - 1).prodi, lokasi = pesan.pemesanan.get(ops - 1).lokasi, status = satu);
                                }
                            }

                        } while (sub != 0);
                    }

                    if (utama == 4) {
                        int dl;
                        do {
                            int stok, harga;
                            String nama;

                            System.out.println("======= Penjualan =======");
                            penjualan.tampilPenjualan();
                            System.out.println("\n");

                            System.out.println("1. Tambah Penjualan");
                            System.out.println("2. Edit Penjualan");
                            System.out.println("3. Hapus Penjualan");
                            System.out.println("0. Keluar");
                            System.out.println("Pilih : ");
                            sub = scan.nextInt();
                            if (sub == 1) {
                                System.out.printf("Nama : ");
                                nama = scan.next();
                                System.out.printf("Stok : ");
                                stok = scan.nextInt();
                                System.out.printf("Harga : ");
                                harga = scan.nextInt();

                                penjualan.addPenjualan(nama, stok, harga);

                            }
                            if (sub == 2) {

                                System.out.println("Pilih Penjualan : ");
                                dl = scan.nextInt();

                                if (dl > 0) {
                                    System.out.printf("Nama : ");
                                    nama = scan.next();
                                    System.out.printf("Stok : ");
                                    stok = scan.nextInt();
                                    System.out.printf("Harga : ");
                                    harga = scan.nextInt();

                                    penjualan.updatePenjualan(nama, stok, harga, dl - 1);
                                } else {
                                    break;
                                }

                            }
                            if (sub == 3) {
                                System.out.println("Pilih Barang : ");
                                dl = scan.nextInt();
                                if (dl > 0) {
                                    penjualan.deletePenjualan(dl - 1);
                                } else {
                                    break;
                                }
                            }

                        } while (sub != 0);

                    }
                    if (utama == 5) {
                        int dl;
                        do {
                            System.out.println("======= Event =======");
                            event.tampilEvent();
                            System.out.println("1. Tambah Event");
                            System.out.println("2. Edit Event");
                            System.out.println("3. Hapus Event");
                            System.out.println("0. Keluar");
                            System.out.println("Pilih : ");
                            sub = scan.nextInt();
                            if (sub == 1) {
                                String ketua, penyelanggara;
                                System.out.printf("Judul : ");
                                judul = scan.next();
                                System.out.printf("Tanggal : ");
                                ketua = scan.next();
                                System.out.println("Penyelenggara : ");
                                penyelanggara = scan.next();
                                event.addEvent(judul, ketua, penyelanggara);
                            }
                            if (sub == 2) {
                                String judul, ketua, penyelanggara;
                                System.out.println("Pilih Event : ");
                                dl = scan.nextInt();

                                if (dl > 0) {
                                    System.out.printf("Judul : ");
                                    judul = scan.next();
                                    System.out.printf("Tanggal : ");
                                    ketua = scan.next();
                                    System.out.println("Nama Penyelenggara : ");
                                    penyelanggara = scan.next();
                                    event.updateEvent(dl - 1, judul, ketua, penyelanggara);
                                } else {
                                    break;
                                }

                            }
                            if (sub == 3) {
                                System.out.println("Pilih Event : ");
                                dl = scan.nextInt();
                                if (dl > 0) {
                                    event.deleteEvent(dl - 1);
                                } else {
                                    break;
                                }
                            }

                        } while (sub != 0);
                    }
//                    
                    if (utama == 6) {
                        int a;
                        
                        System.out.println("\t======= Laporan ======");
                        System.out.println("1. Daftar Komentar");
                        System.out.println("0. Keluar");
                        a = scan.nextInt();
                        if (a == 1) {
                            System.out.println("\t====== Daftar Komentar ======");
                            show.tampil();
                        }
                    }
                } while (utama != 0);

            }
            if (awal == 2) {
                auten.loginMahasiswa();
                do {
                    koperasi.menuUtamaMahasiswa();
                    System.out.print("Pilih : ");
                    utama = scan.nextInt();
                    if (utama == 1) {
                        do{
                            for (int i = 0; i < Koperasi.length; i++) {
                                if (Koperasi[i].getNamaKoperasi() != null) {
                                    System.out.printf(i + 1 + ".");
                                    Koperasi[i].display();
                                }
                            }
                            System.out.println("0. Keluar");
                            sub = scan.nextInt();
                        }while(sub !=0);
                    }
                    if (utama == 2) {
                        do{    
                            System.out.println("\n\t =======Peraturan Koperasi========");
                            for (int i = 0; i < PeraturanKoperasi.length; i++) {
                                if (PeraturanKoperasi[i].getJudul() != null) {
                                    System.out.println(i + 1 + ".");
                                    PeraturanKoperasi[i].display();
                                }
                            }
                            System.out.println("0. Keluar");
                            sub = scan.nextInt();
                        }while(sub !=0);
                    }
                    if (utama == 3) {
                        do{
                            event.tampilEvent();
                            System.out.println("0. Keluar");
                            sub = scan.nextInt();
                        }while(sub !=0);
                    }
                    if (utama == 4) {
                        do {
                            System.out.println("\t======== Daftar Barang =======");
                            barang.tampilkanBarang();
                            System.out.println("\n\t======== Daftar Pemesanan =======");
                            pesan.show();
                            System.out.println("\n");
                            int dl;
                            int jumlah_barang,jumlah,total,alamat1;
                            String nama1, prodi, status, lokasi1 = null;
                            long nim;
                           
                            System.out.println("Nomor Barang : ");
                            dl = scan.nextInt();
                            int pos = dl - 1;

                            for (int i = 0; i < barang.barang.size(); i++) {
                                if (pos == i) {
                                    System.out.println(barang.barang.get(i).nama);
                                    lokasi1 = barang.barang.get(i).nama;
                                }
                            }
                            try {
                            System.out.print("Nama : ");
                            nama1 = scan.next();
                            System.out.print("NIM :");
                            nim = scan.nextLong();
                            System.out.print("Jumlah Barang : ");
                            jumlah_barang = scan.nextInt();
                            System.out.print("Prodi :");
                            prodi = scan.next();
                            
                            for (int i = 0; i < barang.barang.size(); i++) {
                                if (pos == i) {
                                    System.out.println(barang.barang.get(i).nama);
                                    System.out.println("Gabriela");
                                    jumlah = barang.barang.get(i).jumlah_barang- jumlah_barang;
                                    System.out.println(jumlah);
                                    barang.updateBarang(barang.barang.get(dl-1).nama , barang.barang.get(dl-1).jumlah_barang= jumlah, utama = barang.barang.get(dl-1).harga, barang.barang.get(dl-1).tipeBarang.Jajan,  barang.barang.get(dl-1).alamat, dl-1);
                                    
                                }
                            }
                            System.out.print("Total Harga : Rp.");
                            for(int i = 0;i<barang.barang.size();i++){
                                if(pos==i){
                                    total = jumlah_barang * barang.barang.get(i).harga;
                                    System.out.println(total);
                                }
                            }
                            int asd;
                            System.out.println("Apakah anda yakin memesan ?");
                            System.out.println("1. Ya\n2. Tidak");
                            asd = scan.nextInt();
                            if(asd == 1){
                                pesan.pesanBarang(jumlah_barang, nama1, nim, Prodi.valueOf(prodi), lokasi1, status = "Proses");
                            }
                            else if(asd == 2){
                                break;
                            }
                            for (int i = 0; i < barang.barang.size(); i++) {
                                if (pos == i) {
                                    if(barang.barang.get(i).jumlah_barang<0){
                                        System.out.println("Barang Tidak Mencukupi");
                                        pesan.hapusPesanan(i);
                                    }
                                }
                            }
                            }catch (Exception e){
                                     System.err.println("Pesanan Gagal Ditambahkan."); //Tulisan Berwarna Merah
                                 }
                            System.out.println("0. Keluar");
                            System.out.println("Pilih :");
                            sub = scan.nextInt();

                        } while (sub != 0);
                    }
                    if (utama == 5) {
                        String koment;
                        System.out.println("\t========== Komentar ==========");
                        System.out.print("Komentar : ");
                        koment = scan.next();
                        komen.addKomentar(koment);
                    }
                } while (utama != 0);
            }
        } while (awal != 0);
    }

    public void menuLogin() {
        System.out.println("\t======= Login =======");
        System.out.println("1. Petugas");
        System.out.println("2. Mahasiswa");
        System.out.println("0. Keluar");
    }

    public void menuUtamaPetugas() {
        System.out.println("\t========= Selamat Bekerja ==========");
        System.out.println("1. Kelola Profil Koperasi");
        System.out.println("2. Kelola Peraturan Koperasi");
        System.out.println("3. Kelola Koperasi");
        System.out.println("4. Kelola Penjualan");
        System.out.println("5. Kelola Event");
        System.out.println("0. Back");
    }

    public void menuUtamaMahasiswa() {
        System.out.println("\t========= Selamat Berbelanja ==========");
        System.out.println("1. Profil Koperasi");
        System.out.println("2. Peraturan Koperasi");
        System.out.println("3. Informasi Event");
        System.out.println("4. Pemesanan Barang");
        System.out.println("5. Komentar");
        System.out.println("0. Back");
    }

    public void editProfil() {
        System.out.println("\t========Edit Profil=======");
        Scanner scan = new Scanner(System.in);
        System.out.print("Nama Koperasi : ");
        namaKoper = scan.next();
        System.out.print("Lokasi : \n");
        lokasi = scan.next();
        System.out.print("Ketua : ");
        ketua = scan.next();
        System.out.print("Wakil Ketua : ");
        wakil = scan.next();
        System.out.print("Sekertaris : ");
        sekre = scan.next();
        System.out.print("Bendahara : ");
        benda = scan.next();
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
public class PeraturanKoperasi implements Display{
    String judul,Isi,hukuman;

    public PeraturanKoperasi() {
    }

    public PeraturanKoperasi(String judul, String Isi, String hukuman) {
        this.judul = judul;
        this.Isi = Isi;
        this.hukuman = hukuman;
    }

    
    
    public void setPeraturanKoperasi(String judul, String Isi, String hukuman){
        this.Isi = Isi;
        this.judul = judul;
        this.hukuman = hukuman;
    }

    public String getIsi() {
        return Isi;
    }

    public void setIsi(String Isi) {
        this.Isi = Isi;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getHukuman() {
        return hukuman;
    }

    public void setHukuman(String hukuman) {
        this.hukuman = hukuman;
    }

    @Override
    public void display() {
        System.out.println("Judul :\t\t"+judul+"\nTingkat :\t"+Isi+"\nJenis hukuman :\t"+hukuman+"\n");
    }
}
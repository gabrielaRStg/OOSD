/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
import java.util.ArrayList;

public class Pemesanan {
    
    int jumlah_barang;
    String nama;
    long nim;
    Prodi prodi;
    String status;
    String lokasi;
    
    // Collection
    ArrayList<Pemesanan> pemesanan = new ArrayList();

    public Pemesanan() {
        
    }

    // Overload
    public Pemesanan(int jumlah_barang, String nama, long nim, Prodi prodi) {
        this.jumlah_barang = jumlah_barang;
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
    }

    public Pemesanan(int jumlah_barang, String nama, long nim, Prodi prodi, String status) {
        this.jumlah_barang = jumlah_barang;
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.status = status;
    }

    public Pemesanan(int jumlah_barang, String nama, long nim, Prodi prodi, String lokasi, String status) {
        this.jumlah_barang = jumlah_barang;
        this.nama = nama;
        this.nim = nim;
        this.prodi = prodi;
        this.lokasi = lokasi;
        this.status = status;
    }
    
    public void show(){
        System.out.println("No"+"\t\tNama"+"\t\tNIM"+"\t\tProdi"+"\t\tJumlah"+"\t\tLokasi"+"\t\tStatus");
        for(int i = 0;i<pemesanan.size();i++){
            System.out.println(i+1+"\t\t"+pemesanan.get(i).nama+"\t\t"+pemesanan.get(i).nim+"\t\t"+pemesanan.get(i).prodi+"\t\t"+pemesanan.get(i).jumlah_barang+"\t\t"+pemesanan.get(i).lokasi+"\t\t"+pemesanan.get(i).status);
        }
    }
    public void pesanBarang(int jumlah_barang, String nama, long nim, Prodi prodi, String lokasi,String status){
        pemesanan.add(new Pemesanan(jumlah_barang, nama, nim, prodi, lokasi, status));
    }
    
    public void updatePesanan(int ops,int jumlah_barang, String nama, long nim, Prodi prodi,  String lokasi,  String status){
        for(int i = 0;i<pemesanan.size();i++){
             if(ops == i){
                 pemesanan.set(i,new Pemesanan(jumlah_barang, nama, nim, prodi, lokasi, status));
             }
         }
    }
    public void hapusPesanan(int opsi){
        for(int i =0;i<pemesanan.size();i++){
            if(opsi == i){
                pemesanan.remove(i);
            }
        }
    }
}
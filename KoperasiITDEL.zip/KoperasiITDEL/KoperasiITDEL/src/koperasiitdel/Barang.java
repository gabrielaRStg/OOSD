/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
import java.util.ArrayList;

public class Barang {
    
       
    String nama;
    int jumlah_barang;
    int harga;
    String tipe;
    TipeBarang tipeBarang;
    String alamat;
    
    // Collection
    ArrayList<Barang> barang = new ArrayList();
    
    
    // Overload
    public Barang(String nama, int jumlah_barang, int harga, String tipe, String alamat) {
        this.nama = nama;
        this.jumlah_barang = jumlah_barang;
        this.harga = harga;
        this.tipe = tipe;
        this.alamat = alamat;
    }

    public Barang(String nama, int jumlah_barang, int harga, TipeBarang tipeBarang, String alamat) {
        this.nama = nama;
        this.jumlah_barang = jumlah_barang;
        this.harga = harga;
        this.tipeBarang = tipeBarang;
        this.alamat = alamat;
    }
    public Barang() {
        
    }
    
    
     public void tampilkanBarang(){
        System.out.println("No" +"\tNama" + "\tJumlah Barang"+"\tHarga"+"\tTipe"+"\tAlamat");
        for(int i=0;i<barang.size();i++){
            if(barang.get(i).jumlah_barang < 0){
                System.out.println("Barang Kosong");
                barang.remove(i);
                break;
            }
            System.out.println(i+1+". "+"\t"+barang.get(i).nama
                    +"\t"+ barang.get(i).jumlah_barang
                    +"\t"+ barang.get(i).harga
                    +"\t"+ barang.get(i).tipeBarang
                    +"\t"+ barang.get(i).alamat
            );
        }
    }
    
    void addBarang(String nama, int jumlah_barang, int harga, TipeBarang tipeBarang, String alamat) {
        try {
           barang.add(new Barang(nama, jumlah_barang, harga, tipeBarang , alamat));
        }catch(Exception e){
            System.err.println("Gagal Menambah Barang");    //exception handling
        }
    }
    
     public void updateBarang(String nama,int jumlah_barang, int harga,  TipeBarang tipeBarang, String alamat, int opsi){
        barang.set(opsi, new Barang(nama, jumlah_barang, harga, tipeBarang, alamat));
    }
     
    public void deleteBarang(int opsi){
        for(int i=0;i<barang.size();i++){
            if(opsi==i){
                barang.remove(i);
            }
        }
    }
    
    
}
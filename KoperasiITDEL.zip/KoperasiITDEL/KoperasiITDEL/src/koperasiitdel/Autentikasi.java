/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
import java.util.Scanner;

public class Autentikasi implements Acces{
    private String username;    //encapsulation
    private String password;    //encapsulation

    public String getUsername() {
        return this.username;
    }

    
    public String getPassword() {
        return this.password;
    }
    
    @Override
    public void loginPetugas() {
        Scanner scan = new Scanner(System.in);
        Autentikasi autentikasi = new Autentikasi();
        System.out.println("================================");
        System.out.print("Username: ");
        username = scan.nextLine();
        System.out.print("Password: ");
        password = scan.nextLine();

        if("petugas".equals(username) && "petugas".equals(password)){
            System.out.println("Berhasil");
        }else{
            System.out.println("Gagal Login, coba lagi");
            autentikasi.loginPetugas();
        }
    }

    @Override
    public void loginMahasiswa() {
        Scanner scan = new Scanner(System.in);
        Autentikasi autentikasi = new Autentikasi();
        System.out.println("================================");
        System.out.print("Username: ");
        username = scan.nextLine();
        System.out.print("Password: ");
        password = scan.nextLine();

        if("ege".equals(username) && "ege".equals(password)){
            System.out.println("Berhasil");
        }else{
            System.out.println("Gagal Login, coba lagi");
            autentikasi.loginMahasiswa();
        }
    }
    
}
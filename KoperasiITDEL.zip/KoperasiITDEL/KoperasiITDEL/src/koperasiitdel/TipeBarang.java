/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
enum TipeBarang {
    Makanan, Minuman, Jajan;

    static TipeBarang valueOf(TipeBarang tipe) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String toString() {
        switch (this) {
            case Makanan:
                return "Makanan";

            case Minuman:
                return "Minuman";

            default:
                return "Jajan";

        }

    }

}
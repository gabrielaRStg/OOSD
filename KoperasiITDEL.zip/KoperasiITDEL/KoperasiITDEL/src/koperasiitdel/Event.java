/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koperasiitdel;

/**
 *
 * @author ACER
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Event {
    String judul;
    String waktu;
    String penyelanggara;
    ArrayList<Event> event = new ArrayList();

    public Event() {
    }
    
    public Event(String judul, String waktu, String penyelanggara) {
        this.judul = judul;
        this.waktu = waktu;
        this.penyelanggara = penyelanggara;
    }
    
    public void tampilEvent(){
        System.out.println("No." + "\tJudul"+"\t\tTanggal"+"\t\tPenyelenggara");
        for(int i=0;i<event.size();i++){
            System.out.println(i+1+". "+"\t"+event.get(i).judul
                    +"\t"+ event.get(i).waktu
                    +"\t"+ event.get(i).penyelanggara);
        }
    }
    
    public void addEvent(String judul, String waktu, String penyelanggara){
        event.add(new Event(judul,waktu,penyelanggara));
    }
    
    public void deleteEvent(int opsi){
        for(int i=0;i<event.size();i++){
            if(opsi==i){
                event.remove(i);
            }
        }
    }
    
    public void updateEvent(int opsi,String judul, String waktu, String penyelanggara){
        event.set(opsi, new Event(judul,waktu,penyelanggara));
    }
}